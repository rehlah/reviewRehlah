import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'login_page.dart'; // Import login page
import 'registration_page.dart'; // Import registration page
import 'home_page.dart'; // Home page post-login


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();  // Initialize Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Firebase Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),  // Set LoginPage as the default screen
      routes: {
        '/register': (context) => RegistrationPage(),  // Navigate to registration page
        '/home': (context) => HomePage(),  // Navigate to home page after login
      },
    );
  }
}

